package com.eas;

import com.eas.com.eas.AppConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class AppEngine {
    private EASServer server;
    private String instanceID;
    @Autowired
    private AppConfig appConfig;
    public EASServer getServer() {
        return server;
    }

    public void setServer(EASServer server) {
        this.server = server;
    }

    public String getInstanceID() {
        return instanceID;
    }

    public void setInstanceID(String instanceID) {
        this.instanceID = instanceID;
    }

    public void init(){

    }

    public void service() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        String url =appConfig.getUrl();
        String name =appConfig.getName();
        String className =appConfig.getProcessClass();
        Class clz = Class.forName(className);
        Object instance =clz.newInstance();
        System.out.println("Welcome to server {}"+getServer().getServerID());
    }

    public void destroy(){

    }

}
