package com.eas;

import org.springframework.context.annotation.Bean;

import java.util.List;

public class EASServer {
    private int serverID;
    private float availableMemery;

    public int getServerID() {
        return serverID;
    }

    public void setServerID(int serverID) {
        this.serverID = serverID;
    }

    public float getAvailableMemery() {
        return availableMemery;
    }

    public void setAvailableMemery(float availableMemery) {
        this.availableMemery = availableMemery;
    }

    public int getAvailableCPU() {
        return availableCPU;
    }

    public void setAvailableCPU(int availableCPU) {
        this.availableCPU = availableCPU;
    }

    public List<AppEngine> getAppEngineList() {
        return appEngineList;
    }

    public void setAppEngineList(List<AppEngine> appEngineList) {
        this.appEngineList = appEngineList;
    }

    public String getServerStatus() {
        return serverStatus;
    }

    public void setServerStatus(String serverStatus) {
        this.serverStatus = serverStatus;
    }

    private int availableCPU;
    private List<AppEngine> appEngineList;
    private String serverStatus;

    public boolean onHeatBeat(){
        return true;
    }

    public boolean makeServerDown(){
        return true;
    }
}
