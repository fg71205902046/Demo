package com.eas.com.eas.application;

import com.eas.EASServer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class EASApplication {
    public static void main(String[] args) {
        SpringApplication.run(EASApplication.class,args);
    }
    @Bean
    public EASServer getEASServer(){
        return new EASServer();
    }
}
