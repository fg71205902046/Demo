package com.elb;

public interface IRule {
    public static final String ROUNDROBIN = "roundRobin";
    public static final String RANDOM = "random";
    public void IRule();
    public int getNextPosion();
}
