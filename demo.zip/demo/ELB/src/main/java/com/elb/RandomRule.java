package com.elb;

public class RandomRule implements IRule{
    private static int currentIndex;
    @Override
    public void IRule() {
        System.out.println("random rule");
    }

    @Override
    public int getNextPosion() {
        return currentIndex++;
    }

}
