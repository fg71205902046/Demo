package com.elb;

import java.util.Random;

public class RoundRobin implements IRule{
    @Override
    public void IRule() {
        System.out.println("roundRobin rule");
    }

    @Override
    public int getNextPosion() {
        return new Random().nextInt();
    }

}
