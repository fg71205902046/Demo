package com.elb;

import com.eas.EASServer;

import java.util.List;


public class ELBLoadBalanceService {
        private List<EASServer> easServers;
        private int currentIndex;

        public void transferRequest(String ruleName){
                switch (ruleName){
                        case IRule.ROUNDROBIN:
                                chooseLoadBalanceRule(new RoundRobin());
                                break;
                        case IRule.RANDOM:
                                chooseLoadBalanceRule(new RandomRule());
                                break;
                }
        }

        private void chooseLoadBalanceRule(IRule rule){
               int next = rule.getNextPosion()%easServers.size();
               EASServer nextEASServer = easServers.get(next);
        }

}
